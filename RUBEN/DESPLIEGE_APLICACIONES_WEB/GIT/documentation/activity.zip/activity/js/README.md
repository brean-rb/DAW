# Documentation Project

## Description
Project to learn how to document using JSDoc.

## Configuration Instructions
1. Clone the repository.
2. Install JSDoc using `npm install -g jsdoc`.

## Examples of Use
```javascript
subtract(5, 3); // Returns 2
multiply(2, 3); // Returns 6
