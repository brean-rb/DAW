/**
 * Subtracts two numbers.
 * @param {number} a - The minuend.
 * @param {number} b - The subtrahend.
 * @returns {number} - The difference of a and b.
 */
function subtract(a, b) {
    return a - b;
}
