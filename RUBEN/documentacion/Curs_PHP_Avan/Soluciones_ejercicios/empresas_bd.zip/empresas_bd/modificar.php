<?php

/* 
 * Modificar datos de Empresa 
 */
session_start();
?>

<!DOCTYPE html>
<!--
Toma los datos de la nueva empresa. Comprueba que la Razón Social no exista.
-->
<html lang="es">
    <head>
        <meta charset="utf-8">
        <title>Grupo Homero S.</title>
        <meta name="description" content="HTML5, CSS3">
        <meta name="author" content="Toni Boronat">
        <link rel="stylesheet" href="css/estilos.css">
        <title>Alta Empresa</title>
    </head>
<body>
<div id="page">
    <nav>
      <ul>
	<li><a href="index.php">Introducción</a></li>
	<li><a href="empresas.php">Empresas</a>
          <ul>
	    <li><a href="crear.php">Nueva Empresa </a></li>
	    <li><a href="modificar.php">Modificar Empresa </a></li>
	    <li><a href="eliminar.php">Eliminar Empresa </a></li>
          </ul>
	</li>
        <li><a href="empleados.php">Empleados</a>
          <ul>
	    <li><a href="crear_empleado.php">Nuevo Empleado </a></li>
	    <li><a href="modificar_empleado.php">Modificar Empleado </a></li>
	    <li><a href="eliminar_empleado.php">Eliminar Empleado </a></li>
          </ul>
      </ul>
    </nav>    
</div>
</body>
</html>

<?php
include 'buscar_empresa.php';
try{
if(isset($_SESSION["razonsocial"])){
    $razon_social = $_SESSION["razonsocial"];
}
else{
    echo "<form id='formulario' name='modificar' method='post' action= '". $_SERVER['PHP_SELF'] ."' >" ;
    echo "<label>Razón social: </label> <input type='text' name='razonsocial'> <br>";
    echo "<input type='submit' name='modif' value='Modificar'>";
    echo "<input type='submit' name='cancelar' value='Cancelar'>";
    echo "</form>";
}
if(isset($_POST["razonsocial"]) && (strlen($_POST["razonsocial"]) > 0)){
    $razon_social = $_POST["razonsocial"];
    $_SESSION["razonsocial"] = $razon_social;
}
if(isset($razon_social)){
    $empresa = buscar_empresa($razon_social);
    if($empresa != NULL){
        echo "<form id='formulario' name='actualizar' method='post' action= '" . $_SERVER['PHP_SELF'] ."' >" ;
        echo "<label> Domicilio Fiscal: </label> <input type='text' name='domiciliofiscal' value= '". $empresa->getDomicilioFiscal() .  "'> <br>";
        echo "<label> Dominio Web: </label> <input type='text' name='dominioweb' value=" . $empresa->getWeb() .  "> <br>";
        echo "<label> Tipo (SA / SL): </label> <input type='text' name='tipo' value=" . $empresa->getTipo() .  "> <br>";
        echo "<label> Presupuesto Salarios: </label> <input type='text' name='presupuesto' value=" . $empresa->getPresupuestoSalarial() .  "> <br>";
        echo "<input type='submit' name='actualiza' value='Actualizar'>";
        echo "<input type='submit' name='cancelar' value='Cancelar'>";
        echo "</form>";
    }
    else{
        session_destroy();
        echo "Empresa no encontrada<br>";
    }
}
  
if(isset($_POST["actualiza"])){
    $empresa->setDomicilioFiscal($_POST["domiciliofiscal"]);
    $empresa->setWeb($_POST["dominioweb"]);
    $empresa->setTipo($_POST["tipo"]);
    $empresa->setPresupuestoSalarial($_POST["presupuesto"]);
    $cad = serialize($empresa);
    $sql = "UPDATE empresas SET empresa_obj = '" . $cad . "' WHERE razon_social = '" . $razon_social . "'";
    $con_bd = conexion_bd(SERVIDOR, USER, PASSWD,  BASE_DATOS);
    if($con_bd){
        if($res = mysqli_query($con_bd, $sql)) {
            header("Location: mostrarempresa.php");
        }
        else{
            echo "Error en la consulta: " . mysqli_error($con_bd) . "<br>";
        }
    }
    mysqli_close($con_bd);
}
if(isset($_POST["cancelar"])){
   mysqli_close($con_bd);
   session_destroy();
   header("Location: index.php");  
}
}
 catch (Error $e){
     echo "Error al modificar empresa<br>";
     session_destroy();
 }
?>
