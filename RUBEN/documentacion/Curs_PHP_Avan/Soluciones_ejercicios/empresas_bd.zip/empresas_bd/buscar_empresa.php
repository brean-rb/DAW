<?php

/* 
 * Función para buscar una empresa
 */


include "empresa.php";
include "funcion_conexion_bd.php";

DEFINE ("SERVIDOR", "localhost");
DEFINE ("USER", "root");
DEFINE ("PASSWD", "");
DEFINE ("BASE_DATOS", "empresa");

function buscar_empresa($razon_social){
 try{   
  $empresa = NULL;  
  $con_bd = conexion_bd(SERVIDOR, USER, PASSWD,  BASE_DATOS);
  if($con_bd){
        $sql = "SELECT * FROM empresas WHERE razon_social = '" . $razon_social ."'" ;
        if($res = mysqli_query($con_bd, $sql)) {
            if(mysqli_num_rows($res) >=1){
                $res_array = mysqli_fetch_all($res, MYSQLI_ASSOC);
                $empresa = unserialize($res_array[0]["empresa_obj"]);
                mysqli_close($con_bd);
            }
            
        }
  }    
  return $empresa;
 }
 catch (Error $e){
     echo "Error al buscar la empresa<br>";
 }
}
?>