<?php

/* 
 *Ejercicio para la gestión de clases Empresas / Empleados y almacenados en 
 * en BD.
 * El programa permite crear, modificar y eliminar Empresas y sus Empleados.
 * La aplicación usa SERIALIZACIÓN y SESIONES 
 */
session_start();
$_SESSION["razon_social"] = "";
$_SESSION["nss"] = "";
?>

<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Grupo Homero S.</title>
  <meta name="description" content="HTML5, CSS3">
  <meta name="author" content="Toni Boronat">
  <link rel="stylesheet" href="css/estilos.css">
</head>
<body>
  <div id="page">
    <nav>
      <ul>
	<li><a href="index.php">Introducción</a></li>
	<li><a href="empresas.php">Empresas</a>
          <ul>
	    <li><a href="crear.php">Nueva Empresa </a></li>
	    <li><a href="modificar.php">Modificar Empresa </a></li>
	    <li><a href="eliminar.php">Eliminar Empresa </a></li>
          </ul>
	</li>
        <li><a href="empleados.php">Empleados</a>
          <ul>
	    <li><a href="crear_empleado.php">Nuevo Empleado </a></li>
	    <li><a href="modificar_empleado.php">Modificar Empleado </a></li>
	    <li><a href="eliminar_empleado.php">Eliminar Empleado </a></li>
          </ul>
      </ul>
    </nav>
      <main>
          <div id="intro">
            <p>Grupo Homero S.</p>
            <p>Todo lo que usted pueda necesitar</p>
            <p>nosotros se lo podemos dar</p>
          </div>
          <div id="imagenes">
            <a href="empresas.php"><img src="imgs/Ropa-de-trabajo-la-imagen-de-una-empresa.jpg"alt="Empresas"style="width: 400; height: 400"></a>
            <a href="empleados.php"><img src="imgs/1000_empleados_big_0.jpg" alt="Empleados" style="width: 400; height: 400"></a>
          </div>
      </main>  
  </div>
</body>
</html>