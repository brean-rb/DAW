<?php

/* 
 * Mostrar datos de la empresa
 */
session_start();

include 'buscar_empresa.php';
?>

<!DOCTYPE html>
<!--
Toma los datos de la nueva empresa. Comprueba que la Razón Social no exista.
-->
<html lang="es">
    <head>
        <meta charset="utf-8">
        <title>Grupo Homero S.</title>
        <meta name="description" content="HTML5, CSS3">
        <meta name="author" content="Toni Boronat">
        <link rel="stylesheet" href="css/estilos.css">
        <title>Alta Empresa</title>
    </head>
<body>
<div id="page">
    <nav>
      <ul>
	<li><a href="index.php">Introducción</a></li>
	<li><a href="empresas.php">Empresas</a>
          <ul>
	    <li><a href="crear.php">Nueva Empresa </a></li>
	    <li><a href="modificar.php">Modificar Empresa </a></li>
	    <li><a href="eliminar.php">Eliminar Empresa </a></li>
          </ul>
	</li>
        <li><a href="empleados.php">Empleados</a>
          <ul>
	    <li><a href="crear_empleado.php">Nuevo Empleado </a></li>
	    <li><a href="modificar_empleado.php">Modificar Empleado </a></li>
	    <li><a href="eliminar_empleado.php">Eliminar Empleado </a></li>
          </ul>
      </ul>
    </nav>    
    <form id="formulario" name="crear" method="post" action="<?//php echo $_SERVER['PHP_SELF']; ?>" >
        <label>Razón social:    </label> <input type="text" name="razonsocial" ><br>
        <input type="submit" name="crear" value="Crear">
        <input type="submit" name="cancelar" value="Cancelar">
    </form>
</div>
</body>
</html>

<?php
if(isset($_SESSION["razonsocial"])){
    $empresa = buscar_empresa($_SESSION["razonsocial"]);
    echo "<form id='formulario' name='actualizar' method='post' action '" . $_SERVER['PHP_SELF'] ."' >" ;
    $empresa->show();
    echo "<input type='submit' name='actualiza' value='Modificar'>";
    echo "<input type='submit' name='cancelar' value='Cancelar'>";
    echo "</form>";
}
if(isset($_POST["actualiza"])){
    header("Location: modificar.php");
}
if(isset($_POST["cancelar"])){
    session_destroy();
    header("Location: index.php");  
}
?>