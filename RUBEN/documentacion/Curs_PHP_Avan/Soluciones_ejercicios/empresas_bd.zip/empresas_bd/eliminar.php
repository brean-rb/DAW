<?php
/* 
 * Eliminar una empresa con sus empleados.
 */
session_start();
?>

<!DOCTYPE html>
<!--
Toma los datos de la nueva empresa. Comprueba que la Razón Social no exista.
-->
<html lang="es">
    <head>
        <meta charset="utf-8">
        <title>Grupo Homero S.</title>
        <meta name="description" content="HTML5, CSS3">
        <meta name="author" content="Toni Boronat">
        <link rel="stylesheet" href="css/estilos.css">
        <title>Alta Empresa</title>
    </head>
<body>
<div id="page">
    <nav>
      <ul>
	<li><a href="index.php">Introducción</a></li>
	<li><a href="empresas.php">Empresas</a>
          <ul>
	    <li><a href="crear.php">Nueva Empresa </a></li>
	    <li><a href="modificar.php">Modificar Empresa </a></li>
	    <li><a href="eliminar.php">Eliminar Empresa </a></li>
          </ul>
	</li>
        <li><a href="empleados.php">Empleados</a>
          <ul>
	    <li><a href="crear_empleado.php">Nuevo Empleado </a></li>
	    <li><a href="modificar_empleado.php">Modificar Empleado </a></li>
	    <li><a href="eliminar_empleado.php">Eliminar Empleado </a></li>
          </ul>
      </ul>
    </nav>    
</div>
</body>
</html>

<?php
include "empresa.php";
include "funcion_conexion_bd.php";

DEFINE ("SERVIDOR", "localhost");
DEFINE ("USER", "root");
DEFINE ("PASSWD", "");
DEFINE ("BASE_DATOS", "empresa");
try{
if(isset($_SESSION["razonsocial"])){
    $razon_social = $_SESSION["razonsocial"];
}
else{
    echo "<form id ='formulario' name='modificar' method='post' action= '". $_SERVER['PHP_SELF'] ."' >" ;
    echo "<label>Razón social: </label> <input type='text' name='razonsocial'> <br>";
    echo "<input type='submit' name='eliminar' value='Eliminar'>";
    echo "<input type='submit' name='cancelar' value='Cancelar'>";
    echo "</form>";
}
if(isset($_POST["razonsocial"])){
    $razon_social = $_POST["razonsocial"];
    $_SESSION["razonsocial"] = $razon_social;
}
if(isset($razon_social)){
    $con_bd = conexion_bd(SERVIDOR, USER, PASSWD,  BASE_DATOS);
    if($con_bd){
        //Eliminar los empleados
        $sql_empleados = "DELETE FROM empleados WHERE razon_social = '" . $razon_social ."'";
        $sql = "DELETE FROM empresas WHERE razon_social = '" . $razon_social ."'" ;
        if(mysqli_query($con_bd, $sql_empleados)) {
            if(mysqli_affected_rows($con_bd)> 0){
                echo "Empleados  eliminados <br>";
            }    
            if(mysqli_query($con_bd, $sql)) {
                if(mysqli_affected_rows($con_bd)> 0){
                    echo "Empresa  eliminada <br>";
                }
                else{ // No existe la empresa a eliminar
                    session_destroy();
                }
            }
            else{
                echo "Error al eliminar la empresa: " . mysqli_error($con_bd);
            }
        }
        else {
            echo "Error al eliminar los empleados de la empresa: " . mysqli_error($con_bd);
        } 
    }
    mysqli_close($con_bd);
}
if(isset($_POST["cancelar"])){
    session_destroy();
    header("Location: index.php");
}
}
 catch (Error $e){
     echo "Error al eliminar empresa";
     session_destroy();
 }
?>