<?php

/* 
 * Clase para gestionar las conexiones a una base de datos
 */
class bd_obj {
    private $conexion_bd;
    private $sql;
    private $serv;
    private $user;
    private $passwd;
    private $bd;
            
    function __construct($s, $u, $p, $b){
      try{    
        $this->serv = $s;
        $this->user = $u;
        $this->passwd = $p;
        $this->bd =$b;
        $this->sql = "";
        $this->conexion_bd = @mysqli_connect($s, $u, $p, $b);
        if (!$this->conexion_bd) {
            die("Error de conexión a la BD");
        }
      }
      catch (Exception $e){
          echo "Error al crear la conexión a la BD<br>";
     }
    }
    public function getServer(){
            return $this->serv;
    }
    public function getUser(){
            return $this->user;
    }
    public function getPassword(){
            return $this->passwd;
    }
    public function getBD(){
            return $this->bd;
    }
    public function getConexionBD(){
            return $this->conexion_bd;
    }
    public function getSQL(){
            return $this->sql;
    }
    public function setServer($s){
            $this->serv = $s;
    }
    public function setUser($s){
            $this->user = $s;
    }
    public function setPassword($s){
            $this->passwd = $s;
    }
    public function setBD($s){
            $this->bd = $s;
    }
    public function setConexionBD($s, $u, $p, $b){
        if(isset($this->conexion_bd)){
            mysqli_close($this->conexion_bd);
        }
        $this->conexion_bd = @mysqli_connect($s, $u, $p, $b);
        if (!$this->conexion_bd) {
            die("Error de conexión a la BD");
        }  
    }
    public function setSQL($s){
            $this->sql = $s;
    }
    public function gravarBD() {
      try{    
        if(!mysqli_query($this->conexion_bd, $this->sql)) {
            echo "Error en la consulta: " . mysqli_error($this->conexion_bd) . "<br>";
        }
      }
      catch (Exception $e){
          echo "Error al gravar en la BD<br>";
      }
    }
    public function leerBD(){
      try{
        $res_array = NULL;
        if($res = mysqli_query($this->conexion_bd, $this->sql)) {
            if(mysqli_num_rows($res) >=1){
                $res_array = mysqli_fetch_all($res, MYSQLI_ASSOC);
            }
        }
        return $res_array;
      }
      catch(Exception $e){
          echo "Error al leer de la BD<br>";
      }
    }
    public function cerrarBD(){
      try{    
        mysqli_close($this->conexion_bd);
      }
      catch(Exception $e){
          echo "Error al cerrar la conexión a la BD<br>";
      }
    }
    
}
?>
