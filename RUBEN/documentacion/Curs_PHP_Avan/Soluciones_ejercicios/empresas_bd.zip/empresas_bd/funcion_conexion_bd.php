<?php
/* Función para la conexión a una BD */

 
function conexion_bd($serv, $user, $passwd, $bd){  
  $conexion_bd = @mysqli_connect($serv, $user, $passwd, $bd);
  if ($conexion_bd) {
	return($conexion_bd); 
  }
  else {
	die("Error de conexión a la BD");
  }
}
?>
