<?php

/* 
 * Elimina un empleado de la BD
 */
session_start();
?>

<!DOCTYPE html>
<!--
Toma los datos de la nueva empresa. Comprueba que la Razón Social no exista.
-->
<html lang="es">
    <head>
        <meta charset="utf-8">
        <title>Grupo Homero S.</title>
        <meta name="description" content="HTML5, CSS3">
        <meta name="author" content="Toni Boronat">
        <link rel="stylesheet" href="css/estilos.css">
        <title>Alta Empresa</title>
    </head>
<body>
<div id="page">
    <nav>
      <ul>
	<li><a href="index.php">Introducción</a></li>
	<li><a href="empresas.php">Empresas</a>
          <ul>
	    <li><a href="crear.php">Nueva Empresa </a></li>
	    <li><a href="modificar.php">Modificar Empresa </a></li>
	    <li><a href="eliminar.php">Eliminar Empresa </a></li>
          </ul>
	</li>
        <li><a href="empleados.php">Empleados</a>
          <ul>
	    <li><a href="crear_empleado.php">Nuevo Empleado </a></li>
	    <li><a href="modificar_empleado.php">Modificar Empleado </a></li>
	    <li><a href="eliminar_empleado.php">Eliminar Empleado </a></li>
          </ul>
      </ul>
    </nav>    
</div>
</body>
</html>

<?php
include 'bd_obj.php';
include 'empleado.php';
DEFINE ("SERVIDOR", "localhost");
DEFINE ("USER", "root");
DEFINE ("PASSWD", "");
DEFINE ("BASE_DATOS", "empresa");
try {
echo "<form id = 'formulario' name='borrar_empl' method='post' action '" . $_SERVER['PHP_SELF'] ."' >" ;
echo "<label> NSS a buscar: </label> <input type='text' name= 'nss'> <br>";
echo "<input type='submit' name='buscar' value='Buscar'>";
echo "</form>"; 
$empleado = NULL;
$bd = new bd_obj(SERVIDOR, USER, PASSWD, BASE_DATOS);
if(isset($_POST["nss"])){
    $bd->setSQL("SELECT * FROM empleados WHERE nss = ". $_POST["nss"]);
    $empleado_obj = $bd->leerBD();
    if($empleado_obj != NULL){
         $_SESSION["empleado"] = $empleado_obj[0]['empleado_obj'];
         $empleado = unserialize($empleado_obj[0]['empleado_obj']);
         echo "<form id= 'formulario' name='elim_empl' method='post' action= '" . $_SERVER['PHP_SELF'] ."' >" ;
         $empleado->Show();
         echo "<br>";
         echo "<input type='submit' name='elimina_empl' value='Eliminar'>";
         echo "<input type='submit' name='cancelar' value='Cancelar'>";
         echo "</form>";
    }
    else{
        echo "Empleado no encontrado<br>";
    }
}
if(isset($_POST["elimina_empl"]) && isset($_SESSION["empleado"])){
    $empleado_obj = $_SESSION["empleado"];
    $empleado = unserialize($empleado_obj);
    $bd->setSQL("DELETE FROM empleados WHERE nss = '" . $empleado->getNSS() . "'");
    $bd->gravarBD();
    $bd->cerrarBD();
}
if(isset($_POST["cancelar"])){
    session_destroy();
    header("Location:index.php");
}
}
catch(Error $e){
    echo "Error al eliminar empleado<br>";
    session_destroy();
}
?>
