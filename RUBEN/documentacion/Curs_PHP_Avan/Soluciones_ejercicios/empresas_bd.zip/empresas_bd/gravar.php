<?php

/* 
 * Guarda en la BD la nueva empresa 
 * 
 */
session_start();

include "empresa.php";
include "funcion_conexion_bd.php";

DEFINE ("SERVIDOR", "localhost");
DEFINE ("USER", "root");
DEFINE ("PASSWD", "");
DEFINE ("BASE_DATOS", "empresa");
try {
if(isset($_POST["alta"]) && isset($_SESSION["razonsocial"])){
    $empresa = new Empresa($_SESSION["razonsocial"], $_POST["domiciliofiscal"], $_POST["dominioweb"],$_POST["tipo"], $_POST["presupuesto"]);
    $cad = serialize($empresa);
    $razon_social = $_SESSION["razonsocial"];
    $sql = "INSERT INTO empresas (razon_social, empresa_obj) VALUES ('". $razon_social . "', '" . $cad . "')";
    $con_bd = conexion_bd(SERVIDOR, USER, PASSWD,  BASE_DATOS);
    if($con_bd){
        if(!mysqli_query($con_bd, $sql)) {
            echo "Error en la consulta: " . mysqli_error($con_bd) . "<br>";
        }
        mysqli_close($con_bd);
    }
}
header("Location:empresas.php");
}
 catch (Error $e){
     echo "Error al gravar empresa en la BD<br>";
     session_destroy();
 }
?>