<?php

/* 
 * Alta de un nuevo empleado en una empresa
 */
session_start();
?>

<!DOCTYPE html>
<!--
Toma los datos de la nueva empresa. Comprueba que la Razón Social no exista.
-->
<html lang="es">
    <head>
        <meta charset="utf-8">
        <title>Grupo Homero S.</title>
        <meta name="description" content="HTML5, CSS3">
        <meta name="author" content="Toni Boronat">
        <link rel="stylesheet" href="css/estilos.css">
        <title>Alta Empresa</title>
    </head>
<body>
<div id="page">
    <nav>
      <ul>
	<li><a href="index.php">Introducción</a></li>
	<li><a href="empresas.php">Empresas</a>
          <ul>
	    <li><a href="crear.php">Nueva Empresa </a></li>
	    <li><a href="modificar.php">Modificar Empresa </a></li>
	    <li><a href="eliminar.php">Eliminar Empresa </a></li>
          </ul>
	</li>
        <li><a href="empleados.php">Empleados</a>
          <ul>
	    <li><a href="crear_empleado.php">Nuevo Empleado </a></li>
	    <li><a href="modificar_empleado.php">Modificar Empleado </a></li>
	    <li><a href="eliminar_empleado.php">Eliminar Empleado </a></li>
          </ul>
      </ul>
    </nav>    
</div>
</body>
</html>

<?php
include 'bd_obj.php';
include 'empleado.php';
include 'empresa.php';
DEFINE ("SERVIDOR", "localhost");
DEFINE ("USER", "root");
DEFINE ("PASSWD", "");
DEFINE ("BASE_DATOS", "empresa");
try {
$bd = new bd_obj(SERVIDOR, USER, PASSWD, BASE_DATOS);

$bd->setSQL("SELECT * FROM empresas");
$empresas = $bd->leerBD();
$razon_social_array = array();
/*echo "Empresas:<br>";
foreach ($empresas as $value) {
  $razon_social_array[$value["razon_social"]] = $value["empresa_obj"];  
  echo $value["razon_social"] ."<br>";
} */
echo "<div id='formulario'>  Empresas:<br>";
foreach ($empresas as $value) {
  $razon_social_array[$value["razon_social"]] = $value["empresa_obj"];  
  echo $value["razon_social"] ."<br>";
} 
echo "</div>";
// Datos del empleado
echo "<form id = 'formulario' name='alta_empl' method='post' action '" . $_SERVER['PHP_SELF'] ."' >" ;
echo "<label> Elija empresa: </label> <input type='text' name= 'emp'> <br>";
echo "<label> Nombre: </label> <input type='text' name= 'nom'> <br>";
echo "<label> Apellidos: </label> <input type='text' name= 'apell'> <br>";
echo "<label> NSS: </label> <input type='text' name= 'nss'> <br>";
echo "<label> Móbil: </label> <input type='text' name= 'mobil'> <br>";
echo "<label> Salario: </label> <input type='text' name= 'salario'> <br>";
echo "<input type='submit' name='alta' value='Alta'>";
echo "<input type='submit' name='volver' value='Volver'>";
echo "</form>";    

if(isset($_POST["emp"]) && isset($razon_social_array[$_POST["emp"]])){
    $obj_emp = unserialize($razon_social_array[$_POST["emp"]]);
    //Actualiza el presupuesto Salarial de la Empresa
    if($obj_emp->getPresupuestoSalarial() >= $_POST['salario']){
        $obj_emp->setPresupuestoSalarial($obj_emp->getPresupuestoSalarial() - $_POST['salario']);
        $cad = serialize($obj_emp);
        $bd->setSQL("UPDATE empresas SET empresa_obj = '" . $cad . "' WHERE razon_social = '" . $obj_emp->getRazonSocial() . "'");
        $bd->gravarBD();
        $email = $_POST['apell'] . "@" . $obj_emp->getWeb();
        $empleado = new Empleado($_POST['nom'],$_POST['apell'],$_POST['nss'],$email , $_POST['mobil'], $_POST['salario']);
        $cad = serialize($empleado);
        $bd->setSQL("INSERT INTO empleados (nss, razon_social, empleado_obj) VALUES ( '". $_POST['nss']. "','". $obj_emp->getRazonSocial() . "', '" . $cad . "')");
        $bd->gravarBD();
        $bd->cerrarBD();
    }
    else {
        echo "NO hay presupuesto suficiente para este empleado<br>";
    }
}   
else{
    if(isset($_POST["emp"])){
       echo "La empresa elegida no existe<br>";
    }   
}
if(isset($_POST['volver'])){
    header("Location: index.php");
}
}
catch(Error $e){
    echo "Error al crear empleado<br>";
}
?>