<?php
       
        class Persona {
        // Campos de la clase se declaran privados para limitar el acceso
          private $nombre;
          private $apellidos;
          private $nss;
               
          // Constructor toma los parametros para crear los objetos persona
          public function __construct($n, $a, $nss){
            $this->nombre = $n;
            $this->apellidos = $a;
            $this->nss = $nss;
          } // Constructor de persona
          public function __ToString(){
            return "Nombre: " . $this->nombre . "  Apellidos:  " . $this->apellidos . "<br>";
          }
          public function show(){ 
            echo '<table border=1 style= "margin: 0 auto;" >';
            echo '<tr>';
            echo '<th>Nombre</th>';
            echo '<th>Apellidos</th>';
            echo '<th>NSS</th>';
            echo '</tr>';
            echo '<tr>';
            echo '<td>'. $this->nombre . '</td>';
            echo '<td>' . $this->apellidos .'</td>';
            echo '<td>'. $this->nss . '</td>';
            echo '</tr>';
            echo '</table>'; 
          }
          // Métodos get para obtener los atributos
          public function getNombre(){
              return $this->nombre;
          }
          public function getApellidos(){
              return $this->apellidos;
          }
          public function getNSS(){
              return $this->nss;
          }
          // Métodos set para modificar los atributos
          public function setNombre($n){
              $this->nombre = $n;
          }
          public function setApellidos($a){
              $this->apellidos = $a;
          }
          public function setNSS($nss){
              $this->nss = $nss;
          }
        } // Persona
?>



