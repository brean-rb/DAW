<?php

/* 
 * Gestión de empleados
 */
session_start();
?>

<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Grupo Homero S.</title>
  <meta name="description" content="HTML5, CSS3">
  <meta name="author" content="Toni Boronat">
  <link rel="stylesheet" href="css/estilos.css">
</head>
<body>
  <div id="page">
    <header>
      <!--<h1><img src="imgs/logo.png" alt="logo"/>Curso de HTML5 y CSS3</h1>-->
    </header>
    <nav>
      <ul>
	<li><a href="index.php">Introducción</a></li>
	<li><a href="empleados.php">Empleados</a>
          <ul>
	    <li><a href="crear.php">Nuevo Empleado </a></li>
	    <li><a href="modificar.php">Modificar Empleado </a></li>
	    <li><a href="eliminar.php">Eliminar Empleado </a></li>
          </ul>
	</li>
      </ul>
    </nav>
    <ul>
       <li><a href="crear.php">Nuevo Empleado </a></li>
       <li><a href="modificar.php">Modificar Empleado </a></li>
       <li><a href="eliminar.php">Eliminar Empleado </a></li>
    </ul>
  </div>
</body>
</html>