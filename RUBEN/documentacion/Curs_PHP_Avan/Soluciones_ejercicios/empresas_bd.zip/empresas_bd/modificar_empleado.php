<?php

/* 
 * Toma el NSS de un empleado lo busca y permite modificarlo
 */

session_start();
?>

<!DOCTYPE html>
<!--
Toma los datos de la nueva empresa. Comprueba que la Razón Social no exista.
-->
<html lang="es">
    <head>
        <meta charset="utf-8">
        <title>Grupo Homero S.</title>
        <meta name="description" content="HTML5, CSS3">
        <meta name="author" content="Toni Boronat">
        <link rel="stylesheet" href="css/estilos.css">
        <title>Alta Empresa</title>
    </head>
<body>
<div id="page">
    <nav>
      <ul>
	<li><a href="index.php">Introducción</a></li>
	<li><a href="empresas.php">Empresas</a>
          <ul>
	    <li><a href="crear.php">Nueva Empresa </a></li>
	    <li><a href="modificar.php">Modificar Empresa </a></li>
	    <li><a href="eliminar.php">Eliminar Empresa </a></li>
          </ul>
	</li>
        <li><a href="empleados.php">Empleados</a>
          <ul>
	    <li><a href="crear_empleado.php">Nuevo Empleado </a></li>
	    <li><a href="modificar_empleado.php">Modificar Empleado </a></li>
	    <li><a href="eliminar_empleado.php">Eliminar Empleado </a></li>
          </ul>
      </ul>
    </nav>    
</div>
</body>
</html>

<?php
include 'bd_obj.php';
include 'empleado.php';
include 'empresa.php';
DEFINE ("SERVIDOR", "localhost");
DEFINE ("USER", "root");
DEFINE ("PASSWD", "");
DEFINE ("BASE_DATOS", "empresa");
try {
echo "<form id = 'formulario' name='modif_empl' method='post' action '" . $_SERVER['PHP_SELF'] ."' >" ;
echo "<label> NSS a buscar: </label> <input type='text' name= 'nss'> <br>";
echo "<input type='submit' name='buscar' value='Buscar'>";
echo "</form>"; 
$empleado = NULL;
$bd = new bd_obj(SERVIDOR, USER, PASSWD, BASE_DATOS);
if(isset($_POST["nss"])){
    $bd->setSQL("SELECT * FROM empleados WHERE nss = ". $_POST["nss"]);
    $empleado_obj = $bd->leerBD();
    if($empleado_obj != NULL){
        $_SESSION["empleado"] = $empleado_obj[0]['empleado_obj'];
        $_SESSION["empresa"] = $empleado_obj[0]['razon_social'];
        $empleado = unserialize($empleado_obj[0]['empleado_obj']);
        echo "<form id= 'formulario' name='actualizar' method='post' action= '" . $_SERVER['PHP_SELF'] ."' >" ;
        echo "<label> Nombre: </label> <input type='text' name='nom' value= '". $empleado->getNombre() .  "'> <br>";
        echo "<label> Apellidos: </label> <input type='text' name='apell' value=" . $empleado->getApellidos() .  "> <br>";
        echo "<label> NSS: ". $empleado->getNSS() .  "</label><br>";
        echo "<label> Email: </label> <input type='text' name='email' value=" . $empleado->getEmail() .  "> <br>";
        echo "<label> Móbil: </label> <input type='text' name='mobil' value=" . $empleado->getMovil() .  "> <br>";
        echo "<label> Salario: </label> <input type='text' name='salario' value=" . $empleado->getSalario() .  "> <br>";
        echo "<input type='submit' name='actualiza' value='Actualizar'>";
        echo "<input type='submit' name='cancelar' value='Cancelar'>";
        echo "</form>";
    }
    else{
        echo "Empleado no encontrado<br>";
    }
}
  
if(isset($_POST["actualiza"]) && isset($_SESSION["empleado"])){
    $empleado_obj = $_SESSION["empleado"];
    $empleado = unserialize($empleado_obj);
    $hay_presupuesto = TRUE;
    //Actualizar el Presupuesto Salarial si varía el del empleado
    if($empleado->getSalario() != $_POST["salario"] ){
        $bd->setSQL("SELECT * FROM empresas WHERE razon_social = '". $_SESSION['empresa'] . "'");
        $empresa_obj = $bd->leerBD();
        $empresa = unserialize($empresa_obj[0]['empresa_obj']);
        if(((int)$empresa->getPresupuestoSalarial()+(int)$empleado->getSalario()-(int)$_POST["salario"]) >= 0 ){
            $empresa->setPresupuestoSalarial((int)$empresa->getPresupuestoSalarial()+(int)$empleado->getSalario()-(int)$_POST["salario"]);
            $cad = serialize($empresa);
            $bd->setSQL("UPDATE empresas SET empresa_obj = '" . $cad . "' WHERE razon_social = '" . $empresa->getRazonSocial() . "'");
            $bd->gravarBD();
        }
        else{
            echo "No hay presupuesto para el aumento de sueldo<br>";
            $hay_presupuesto = FALSE;
            $bd->cerrarBD();
        }
         $hay_presupuesto = FALSE;
    }
    if($hay_presupuesto === TRUE){
        $empleado->setNombre($_POST["nom"]);
        $empleado->setApellidos($_POST["apell"]);
        $empleado->setEmail($_POST["email"]);
        $empleado->setMovil($_POST["mobil"]);
        $empleado->setSalario($_POST["salario"]);
        $cad = serialize($empleado);
        $bd->setSQL("UPDATE empleados SET empleado_obj = '" . $cad . "' WHERE nss = '" . $empleado->getNSS() . "'");
        $bd->gravarBD();
        $bd->cerrarBD();
        echo "<div id='formulario'>";
        echo "Actualizado:";
        $empleado->Show();
        echo "</div>";
    }    
}
if(isset($_POST["cancelar"])){
    session_destroy();
    header("Location:index.php");
}
}
catch(Exception $e){
    echo "Error al modificar empleado<br>";
    session_destroy();
}
?>
