<?php

/* 
 * Crear una nueva empresa.
 */
session_start();
?>

<!DOCTYPE html>
<!--
Toma los datos de la nueva empresa. Comprueba que la Razón Social no exista.
-->
<html lang="es">
    <head>
        <meta charset="utf-8">
        <title>Grupo Homero S.</title>
        <meta name="description" content="HTML5, CSS3">
        <meta name="author" content="Toni Boronat">
        <link rel="stylesheet" href="css/estilos.css">
        <title>Alta Empresa</title>
    </head>
<body>
<div id="page">
    <nav>
      <ul>
	<li><a href="index.php">Introducción</a></li>
	<li><a href="empresas.php">Empresas</a>
          <ul>
	    <li><a href="crear.php">Nueva Empresa </a></li>
	    <li><a href="modificar.php">Modificar Empresa </a></li>
	    <li><a href="eliminar.php">Eliminar Empresa </a></li>
          </ul>
	</li>
        <li><a href="empleados.php">Empleados</a>
          <ul>
	    <li><a href="crear_empleado.php">Nuevo Empleado </a></li>
	    <li><a href="modificar_empleado.php">Modificar Empleado </a></li>
	    <li><a href="eliminar_empleado.php">Eliminar Empleado </a></li>
          </ul>
      </ul>
    </nav>    
    <form id="formulario" name="crear" method="post" action="<?//php echo $_SERVER['PHP_SELF']; ?>" >
        <label>Razón social:    </label> <input type="text" name="razonsocial" ><br>
        <input type="submit" name="crear" value="Crear">
        <input type="submit" name="cancelar" value="Cancelar">
    </form>
</div>
</body>
</html>

<?php
include 'buscar_empresa.php';
//Comprueba si ya existe la empresa
try {
 if(isset($_POST["razonsocial"]) && (strlen($_POST["razonsocial"]) > 0)){
    $_SESSION["razonsocial"] = $_POST["razonsocial"];
    // Comprueba si está en la BD
    $empresa = buscar_empresa($_POST["razonsocial"]);
    if($empresa == NULL){ // No existe, toma los datos para crearla
        //Toma los datos de la nueva Empresa
        echo "<form name='altaempr' method='post' action= 'gravar.php' >" ;
        echo "<label> Domicilio Fiscal: </label> <input type='text' name='domiciliofiscal'> <br>";
        echo "<label> Dominio Web: </label> <input type='text' name='dominioweb'> <br>";
        echo "<label> Tipo (SA / SL): </label> <input type='text' name='tipo'> <br>";
        echo "<label> Presupuesto Salarios: </label> <input type='text' name='presupuesto'> <br>";
        echo "<input type='submit' name='alta' value='Alta'>";
        echo "<input type='reset' name='borrar' value='Borrar'>";
        echo "</form>";
    }
    else{
        echo "La empresa ya existe<br>";
    }
  }
  if(isset($_POST["cancelar"])){
   session_destroy();
   header("Location: index.php"); 
  }
}
 catch (Error $e){
     echo "Error al crear empresa<br>";
     session_destroy();
 }
?>