<!DOCTYPE html>
<!--
Ejercicio para desarrollar una calculadora básica con:  textarea
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
           
           if(isset($_REQUEST["num"])){
               // La var cadena se usa para mantener los datos introducidos
               $entrada = $_REQUEST["cadena"] . $_REQUEST["num"];
           }
           if(isset($_REQUEST["calc"])){
               // Convertimos la cadena en números y operaciones
              if(isset($_REQUEST["entrada"])){
                  $cadena=$_REQUEST["entrada"]; // Si pone los valores por teclado
              }
              else{
                  $cadena= $_REQUEST["cadena"];
              }
              
               // preg_split extrae los operandos y los guarda en un array
               $operandos=preg_split("/[\+\-\*\/\(\)]/", $cadena);
               $pos = 0;
               foreach ($operandos as $oper){
                   $pos+=strlen($oper);
                   $operacion[] = substr($cadena,$pos ,1); //Extrae el signo de la operacion
                   $pos++; //Salta el signo de la operacion que acaba de extraer
               }
               // Calcula las operaciones
               $aux = (float) $operandos[0];
               for($i=1; $i < count($operandos) ; $i++){
                   switch ($operacion[$i-1]){
                    case '+': $aux = $aux + (float) $operandos[$i];
                        break;
                    case '-': $aux = $aux - (float) $operandos[$i]; 
                        break;
                    case '*': $aux = $aux * (float) $operandos[$i]; 
                        break;
                    case '/': $aux = $aux / (float) $operandos[$i]; 
                        break;
                   }
               }
               // Pone el resultado
               $entrada = (string)$aux; 
                              
               // Con eval calcula y presenta el resultado
               //eval('$entrada='.$cadena. ';');
           }
           if(isset($_REQUEST["borrar"])){
               $entrada="";
           }
              
        ?>
        <form name="calculadora" method="post" action="<?= $PHP_SELF ?>" >
        <table border="1">
            <tr>
                <td colspan="4"> <input type="text" name="entrada" value="<?= $entrada?>"> <input type="hidden" name="cadena" value="<?= $entrada ?>"> </td>
                
                <td> <input type="submit" name="borrar" value="cls"> </td>
            </tr>
            <tr>
                <td style="text-align:center"; ><input type="submit" name="num" value="7"> </td>
                <td style="text-align:center"; ><input type="submit" name="num" value="8"></td>
                <td style="text-align:center"; ><input type="submit" name="num" value="9"></td>
                <td style="text-align:center"; ><input type="submit" name="num" value="/"></td>
            </tr>
            <tr>
                <td style="text-align:center"; ><input type="submit" name="num" value="4"></td>
                <td style="text-align:center"; ><input type="submit" name="num" value="5"></td>
                <td style="text-align:center"; ><input type="submit" name="num" value="6"></td>
                <td style="text-align:center"; ><input type="submit" name="num" value="*"></td>
            </tr>
            <tr>
                <td style="text-align:center"; ><input type="submit" name="num" value="1"></td>
                <td style="text-align:center"; ><input type="submit" name="num" value="2"></td>
                <td style="text-align:center"; ><input type="submit" name="num" value="3"></td>
                <td style="text-align:center"; ><input type="submit" name="num" value="-"></td>
            </tr>
            <tr>
                <td style="text-align:center"; ><input type="submit" name="num" value="0"></td>
                <td style="text-align:center"; ><input type="submit" name="calc" value="="></td>
                <td style="text-align:center"; ><input type="submit" name="num" value="."></td>
                <td style="text-align:center"; ><input type="submit" name="num" value="+"></td>
            </tr>
        </table> 
        </form>    
    </body>
</html>
