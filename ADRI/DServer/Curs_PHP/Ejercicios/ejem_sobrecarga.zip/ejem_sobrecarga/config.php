<?php
  define("IVA", 0.21);

  define("PRECIOS", "ficheros/precios.txt");
  define("SOCIOS", "ficheros/socios.txt");
  define("MONITORES", "ficheros/monitor.txt");
  define("REGISTRO", "ficheros/registro.txt");

?>
