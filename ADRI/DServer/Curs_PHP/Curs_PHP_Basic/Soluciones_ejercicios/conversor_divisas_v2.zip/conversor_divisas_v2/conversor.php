<?php

if(isset($_POST["calcular"])){
    if(isset($_POST["valor1"])) {
        $v1= (float)$_POST["valor1"];
    }
    if(isset($_POST["valor2"])) {
        $v2= (float)$_POST["valor2"];
    }
    if(isset($_POST["divisa1"])) {
        $d1= strtolower($_POST["divisa1"]);
    }
    if(isset($_POST["divisa2"])) {
        $d2= strtolower($_POST["divisa2"]);
    }
      
    $v2 = (float)$_POST[$d2] / (float)$_POST[$d1];
    
    $res = $v1 * $v2;
    echo $d1 . ": " . $v1 . "<br>";
    echo $d2 . ": " . $v2 . "<br>";
    echo "Conversion: " . $res . "<br>";

    echo '<form name="conversor_divisas2" method="post" action="index.php" >';
    echo '<input type="submit" name="Volver" value="Volver"> ';
    echo '</form>';
} //if(isset($_POST["calcular"]

?>
