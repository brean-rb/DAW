/* 
 * Script para gestionar los valores mostrados de la divisa seleccionada
 * 
 */

//document.getElementById("divi2").onchange = function() {valor_conversion()};
function valorconversion() 
{
     var d = document.getElementById("divi2").value ;
     switch (d) {
         case "Dolar" : 
             document.getElementById("val2").value =  document.getElementById("dolar").value ;
             break;
         case "Euro" : 
             document.getElementById("val2").value =  1 ;
             break;    
         case "Libra" : 
             document.getElementById("val2").value =  document.getElementById("libra").value ;
             break; 
     }
}
