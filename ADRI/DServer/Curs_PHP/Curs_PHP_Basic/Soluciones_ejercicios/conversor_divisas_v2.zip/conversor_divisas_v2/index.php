<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <script src="/conversor_divisas_v2/conversor.js" type="text/javascript" ></script> 
    </head>
    <body>
        <?php
             if (is_readable("/home/aboronat/www/conversor_divisas_v2/divisas.txt")) {
                $fich = fopen("/home/aboronat/www/conversor_divisas_v2/divisas.txt", "r");
                if($fich) {
                    while(!feof($fich)){
                        $divisas = fgets($fich); // Lee línea a línea
                        //Extraemos del string los valores de las divisas
                        $aux = explode("=", $divisas);
                        $cotizaciones[$aux[0]] = $aux[1];
                    }
                    fclose($fich); // Cierra el fichero ya tenemos su contenido
                    echo '<form name="conversor_divisas" method="post" action="conversor.php" >';
                    foreach ($cotizaciones as $clave => $valor){
                        echo "<input type=hidden id=" . $clave . " name=" . $clave . " value= " . $valor . " >";
                    }
                    echo "<select name='divisa1' >";
                    echo "<option> Euro </option>";
                    echo "<option> Dolar </option>";
                    echo "<option> Libra </option>";
                    echo "</select>";
                    echo '<input  type="text"   name="valor1" value="1"> <br>';
                    echo '<select id="divi2" onchange="valorconversion()" name="divisa2"  >';
                    echo '<option value="Dolar" > Dolar </option>';
                    echo '<option value="Euro" > Euro </option>';
                    echo '<option value="Libra" > Libra </option>';
                    echo "</select>";
                    echo '<input id="val2" type="text" name="valor2" value="' . $cotizaciones["dolar"]  .'" > <br>';
                    
                    echo '<input type="submit" name="calcular" value="Calcular"> ';
                    echo '<input type="reset" name="borrar" value="Borrar">';
                    echo '</form>';
           
                }
                else{
                    exit("<br><br><br>Error al abrir el fichero de divisas <br>");
                }
             }
             else{
                exit("<br><br><br>Error al abrir el fichero de divisas <br>");
             }
        ?>
    </body>
</html>
