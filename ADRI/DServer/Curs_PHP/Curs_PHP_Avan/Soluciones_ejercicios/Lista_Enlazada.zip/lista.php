<?php
// Implementa la lista de nodos
include 'nodo.php';
class Lista implements Iterator {
  private $cabeza;
  private $cola;
  private $actual;
  
  public function __construct() {
      $this->cabeza = null;
      $this->cola = $this->cabeza;
      $this->actual = $this->cabeza;
  }    
  public function __destruct() {
       echo "<br>Eliminando lista";
       $sig = $this->cabeza;
       while ($sig->getSiguiente() != NULL){
        $aux = $sig->getSiguiente();
        unset($sig); //Elimina los nodos y llama a __destruct()
        $sig = $aux;
       }
       unset($sig);
  }
  // Esta función crea un copia per no es independiente de la original
  public function __clone(){
      $this->cabeza = clone $this->cabeza;
      $this->rewind();
      while($this->valid()){
        $this->actual = clone $this->actual;
        $this->next();
      }
      $this->cola = clone $this->cola;
  }
  // Implementa la interfaz Iterator
  public function rewind(){
    $this->actual = $this->cabeza;
  }
  public function valid(){  
    return isset($this->actual);
  }
  public function key(){
    return $this->actual;
  }
  public function current(){
    return $this->actual->getDato();
  }
  public function next() {
    $this->actual = $this->actual->getSiguiente();
  }
  public function getCabeza() {
      return $this->cabeza;   
  }
  public function getCola() {
      return $this->cola;   
  }
  public function getActual() {
      return $this->actual;   
  }
  public function insertarCabeza($d) {
      $nodo_aux =$this->cabeza;
      $this->cabeza = new nodo($d);
      $this->cabeza->setSiguiente($nodo_aux);
      if($this->cola == null){
          $this->cola = $this->cabeza;
          $this->actual = $this->cola;
      }
  }
  public function insertarCola($d) {
      $nodo_aux =$this->cola;
      $this->cola = new nodo($d);
      if($nodo_aux != NULL){
        $nodo_aux->setSiguiente($this->cola);
      }  
      if($this->cabeza == null){
          $this->cabeza = $this->cola;
          $this->actual = $this->cola;
      }
  }
  public function esVacia() {
      if($this->cabeza == null)
        $aux = TRUE;
      else
        $aux = FALSE;
      return $aux;
  }
  /*public function mostrarLista() { //Con getSiguiente
    echo "<br>Lista:";
    $sig = $this->cabeza;
    while ($sig->getSiguiente() != NULL){
        echo "<br>Dato: " . $sig->getDato();
        $sig = $sig->getSiguiente();
    }
    echo "<br>Dato: " . $sig->getDato();
  }*/
  public function mostrarLista() { //Con funciones Iterator
    echo "<br>Lista:";
    $this->rewind();
    while($this->valid()){
        echo "<br>Dato: " . $this->actual->getDato();
        $this->next();
    }
  }
  public function buscarNodo($d){
     $this->rewind();
     $dato =  $this->actual->getDato();
     while($this->valid() && ($dato != $d)){
        $this->next();
        if($this->valid()){
            $dato =  $this->actual->getDato();
        }
     }
     if($dato == $d){
         return $this->actual;
     }
     else {
         return NULL;
     }
  }
  public function eliminarNodo($d){
      $aux = $this->buscarNodo($d);
      if($aux != NULL){
        $this->rewind();
        $ant = $this->cabeza;
        $dato =  $this->actual->getDato();
        while($dato != $d){
            $ant = $this->actual;
            $this->next();
            if($this->valid()){
                $dato =  $this->actual->getDato();
            }
            
        }
        if($this->cabeza == $this->actual){
            $this->cabeza = $this->actual->getSiguiente();
        }
        if($this->cola == $this->actual){
            $this->cola = $ant;
        }
        $ant->setSiguiente($this->actual->getSiguiente());
        unset($this->actual);
      } 
      $this->rewind();
  }
} // Class Lista


?>
