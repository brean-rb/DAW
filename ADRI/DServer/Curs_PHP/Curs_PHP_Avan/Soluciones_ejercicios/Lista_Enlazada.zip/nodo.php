<?php
// Elemento de la lista
    class nodo {
        private $dato;
        private $siguiente; // Tendrá el siguiente elemento de la lista
        
        public function __construct($d) {
            $this->dato = $d;
            $this->siguiente = null;
        }
        public function __destruct() {
            echo "<br>Nodo " . $this->dato . " eliminado";
        }
        public function __toString() {
            return $this->dato;
        }
        public function getDato() {
            return $this->dato;
        }
        public function getSiguiente() {
            return $this->siguiente;
        }
        public function setDato($d) {
            $this->dato = $d;
        }
        public function setSiguiente($s) {
            $this->siguiente = $s;
        }
       /* public function __clone(){
            $this->dato =  $this->dato;
            $this->siguiente = $this->siguiente;
        }*/
    } // Class nodo
?>

