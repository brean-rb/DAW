<?php
// Ejemplo de Lista Enlazada según ejercicio PHP Avanzado tema Evolución 
include "lista.php";
// Operaciones variadas sobre los métodos de la clase lista
$l = new Lista();
$l->insertarCabeza(1);
$l->insertarCabeza(2);
$l->insertarCabeza(3);
$l->mostrarLista();
$l->insertarCola(4);
$l->mostrarLista();
unset($l); // Elimina la lista y llama a __destruct()
//$l_clon = clone $l;
echo "<br>clon:";
//$l_clon->mostrarLista();
echo "<br><br>";
//$l_clon->insertarCabeza(5);
//$l_clon->insertarCola(5);
//$l->mostrarLista();
//$l_clon->mostrarLista();
$l2 = new Lista();
$l2->insertarCola("a");
$l2->insertarCola("b");
$l2->insertarCola("c");
$l2->mostrarLista();
$l2->insertarCabeza("D");
$l2->mostrarLista();
$aux = $l2->buscarNodo("a");
if($aux != NULL){
    echo "<br>Buscar nodo: " . $aux;
}
else{
    echo "<br>Nodo no encontrado.";
}
$l2->eliminarNodo("c");
$l2->insertarCola("X");
$l2->mostrarLista();
echo "<br>". $l2->mostrarLista();
$l2->rewind();
echo "Primero: " . $l2->current();
$l2->next();
echo "<br>Segundo: " . $l2->current();
$l2->rewind();
echo "<br><br>";
echo "Primero: " . $l2->current();
$l2->next();
echo "<br>Segundo: " . $l2->current();
$l2->next();
if($l2->valid()){
    echo "<br>Otro: " . $l2->current();
    $l2->next();
}
else{
    echo "<br>Final de lista";
}
$l3 = clone $l2;
unset($l2);
echo "<br><br>Mostrar l3<br>";
$l3->insertarCabeza("d");
$l3->insertarCola("e");
$l3->mostrarLista();
echo"<br>";
$l3->mostrarLista();

?>