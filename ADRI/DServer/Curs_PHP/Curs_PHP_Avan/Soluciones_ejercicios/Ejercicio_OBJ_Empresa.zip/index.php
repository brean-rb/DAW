<!DOCTYPE html>
<!--
Ejercicio Empresa de PHP Avanzado Evolución 2.1
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
            include 'empresa.php';
            $e1 = new Empresa("Homero", "c/Del Pino,32", "homero.com", "SA", 2000000);
            try{ // Hay un excepcion si no hay presupuesto para nuevos empleados
              $e1->setEmpleado("Mariano", "Martínez", "1234567", "homero.com", "666666666",200000);
              $e1->setEmpleado("Rosa", "Pérez", "19191919", "homero.com", "611111111",2200);
            }
            catch (Exception $e){
                echo "<br>Excepción: " . $e->getMessage() ."<br>";
            }
            $e1->show();
            
        ?>
    </body>
</html>
