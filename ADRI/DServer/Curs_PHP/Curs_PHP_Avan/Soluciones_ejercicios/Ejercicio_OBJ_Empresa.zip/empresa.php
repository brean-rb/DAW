<?php
    include 'empleado.php';
    class Empresa {
        // Atributos de la empresa
        private $razon_social;
        private $dom_fiscal;
        private $web; // Dominio de la empresa, lo usaremos para los email
        private $tipo;
        private $presup_salarios;
        private $empleados = array(); // Array con los empleados
        
        // Constructor Empresa
        public function __construct($rs,$df,$w,$t,$ps) {
            $this->razon_social = $rs;
            $this->dom_fiscal = $df;
            $this->web = $w;
            $this->tipo = $t;
            $this->presup_salarios = $ps;
            // Los empleados los añadiremos uno a uno con setEmpleado()
        }// __construct()
        // Métodos para obtener atributos
        public function getRazonSocial() {
            return $this->razon_social;
        }
        public function getDomicilioFiscal() {
            return $this->dom_fiscal;
        }
        public function getWeb() {
            return $this->web;
        }
        public function getTipo() {
            return $this->tipo;
        }
        public function getPresupuestoSalarial() {
            return $this->presup_salarios;
        }
        public function getempleados() {
            return $this->empleados;
        }
        //Métodos para modificar atributos
        public function setRazonSocial($rs) {
            $this->razon_social = $rs;
        }
        public function setDomicilioFiscal($df) {
            $this->dom_fiscal = $df;
        }
        public function setWeb($w) {
            $this->web = $w;
        }
        public function setTipo($t) {
            $this->tipo = $t;
        }
        public function setPresupuestoSalarial($ps) {
            $this->presup_salarios = $ps;
        }
        public function setEmpleado($n, $a, $nss, $e, $m, $s) {
            // Antes de añadir el empleado comprobamos que hay presupuesto
            $this->presup_salarios -= $s;
            if($this->presup_salarios >= 0){
               $this->empleados[] = new Empleado($n, $a, $nss, $e, $m, $s);
            }
            else{
                //Restablece el valor al no crear el empleado
                $this->presup_salarios += $s; 
                throw new Exception("Sin presupuesto para el nuevo empleado");
            }
                
        }
        public function show(){
            echo "Razon Social: " . $this->razon_social . "<br>";
            echo "Domicilio Fiscal: " . $this->dom_fiscal . "<br>";
            echo "Dominio Web: " . $this->web . "<br>";
            echo "Presupuesto Salarial: " . $this->presup_salarios . "<br>";
            echo "Empleados:<br>";
            foreach ($this->empleados as $empleado) {
                $empleado->show();
                echo "<br>";
            }
        }
    } // class Empresa
?>

