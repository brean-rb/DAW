<?php
    include_once 'persona.php'; //Contiene la clase Persona
    class Empleado extends Persona {
         // Añadimos nuevos atributos propios de cliente
    	private $email;
    	private $movil;
    	private $salario;
        
        // Constructor de Cliente
        public function __construct ($n, $a, $nss, $e, $m, $s) {
            //Llama al constructor de la clase base
            parent::__construct($n, $a, $nss);
            // Asigna los atributos propios de la clase derivada
            $this->email = $e;
            $this->movil = $m;
            $this->salario = $s;
        } // __construct()
        public function __ToString(){ //Usa la de la clase base --> Persona
            return parent::__ToString() . " Email: " . $this->email . "Móvil: " . $this->movil . "<br>";
        }
        // Métodos get para obtener los atributos
        public function getEmail(){
            return $this->email;
        }
        public function getMovil(){//...
            return $this->movil;
        }
        public function getSalario(){
            return $this->salario;
        }
        // Métodos set para modificar los atributos
        public function setEmail($e){
            $this->email = $e;
        }
        public function setMovil($m){
            $this->movil = $m;
        }
        public function setSalario($s){
            $this->salario = $s;
        }
        public function show(){
            parent::show();
            echo '<table border=1>';
            echo '<tr>';
            echo '<th>Email</th>';
            echo '<th>Móvil</th>';
            echo '<th>Salario</th>';
            echo '</tr>';
            echo '<tr>';
            echo '<td>'. $this->email . '</td>';
            echo '<td>' . $this->movil .'</td>';
            echo '<td>' . $this->salario .'</td>';
            echo '</tr>';
            echo '</table>';
        }
    }// Cliente
?>


