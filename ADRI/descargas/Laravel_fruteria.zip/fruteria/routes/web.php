<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\FrutaController;
use App\Http\Controllers\LoginController;
use App\Models\Fruta;

Route::get('/', function () {
    return view('inicio');
 })->name('inicio');

Route::get('login', [LoginController::class, 'loginForm'])->name('login');
Route::post('login', [LoginController::class, 'login']);
Route::get('logout',[LoginController::class, 'logout'])->name('logout');

Route::get('lf', function(){
    $frutas = Fruta::get();
    return view('frutas.index', compact('frutas'));
})->name('listado');

// Precio mínimo de fruta
Route::get('preciomin', function(){
    $frutaMin = Fruta::orderby('precio_kg', 'asc')->first();
    return view('frutas.maxmin', compact('frutaMin'));
})
->middleware('auth')
->name('minimo');

Route::resource('frutas', FrutaController::class)
->middleware('auth')
->names(['index'=>'listado_frutas', 'show'=>'fruta', 'destroy'=>'eliminar']);

// Precio más alto de fruta
Route::get('/preciomax/', [FrutaController::class, 'preciomax'])
->middleware('auth')
->name('maximo');

//require __DIR__.'/auth.php';
