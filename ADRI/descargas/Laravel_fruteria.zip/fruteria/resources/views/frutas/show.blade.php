<html>
    <head>
        <title>Fruta</title>
    </head>
    <body>
        <h3>Fruta</h3>
        @isset($error_eliminar)
          {{ $error_eliminar }}
        @endif
        @isset($error)
          {{ $error }}
        @endif

        @isset($fruta)
          {{$fruta->nombre}}    {{$fruta->precio_kg}}   {{$fruta->origen->origen}} {{$fruta->temporada->temporada}}
          <form action="{{ route('frutas.edit', $fruta->id) }}" method="GET">
            @csrf
            <input type="submit" name="modificar" value="Modificar" />
          </form>
          <form action="{{ route('eliminar', $fruta->id) }}" method="POST">
            @csrf
            @method("DELETE")
            <input type="submit" name="eliminar" value="Eliminar" />
          </form>
        @endisset
        <p><a href=" {{ route('inicio')}}">Inicio</a></p>

    </body>
</html>
