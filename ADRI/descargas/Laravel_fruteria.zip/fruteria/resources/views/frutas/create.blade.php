<html>
    <head>
        <title>Nueva fruta</title>
    </head>
    <body>
        <h3>Nueva fruta</h3>
        <form name="nueva" action="{{ route('frutas.store') }}" method="POST">
            @csrf
            <div>
            <label for="nombre">Nombre:</label>
            <input type="text" name="nombre" value="{{old('nombre')}}">
            </div>
            <div>
            <label for="precio_kg">Precio_Kg:</label>
            <input type="text" name="precio_kg" value="{{old('precio_kg')}}">
            </div>
            <div>
            <label for="temporada_id">Temporada:</label>
            <select name="temporada_id">
               @foreach ($temporadas as $temporada)
                   <option value="{{ $temporada->id }}">
                     {{$temporada->temporada}}
                   </option>
               @endforeach
            </select>
            </div>
            <div>
            <label for="origen_id">Origen:</label>
            <select name="origen_id">
               @foreach ($origenes as $origen)
                   <option value="{{ $origen->id }}">
                     {{$origen->origen}}
                   </option>
               @endforeach
            </select>
            <p><label for="nuevo_origen">Nuevo origen:</label>
            <input type="text" name="nuevo_origen">
            </p>
            </div>

            <div>
            <input type="submit" name="crear" value="Crear">
            </div>
        </form>
    </body>
</html>

