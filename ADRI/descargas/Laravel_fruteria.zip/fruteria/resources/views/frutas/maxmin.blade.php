<html>
    <head>
        <title>Fruta precios max o min</title>
    </head>
    <body>
        @isset($frutaMin)
          <h3>Fruta con precio mínimo</h3>
          {{$frutaMin->nombre}}    {{$frutaMin->precio_kg}}   {{$frutaMin->origen->origen}} {{$frutaMin->temporada->temporada}}
        @endisset
        @isset($frutaMax)
           <h3>Fruta con precio máximo</h3>
          {{$frutaMax->nombre}}    {{$frutaMax->precio_kg}}   {{$frutaMax->origen->origen}} {{$frutaMax->temporada->temporada}}
        @endisset
        <p><a href=" {{ route('inicio')}}">Inicio</a></p>

    </body>
</html>
