<html>
    <head>
        <title>Listado de frutas</title>
    </head>
    <body>
        <h3>Listado de frutas</h3>
        <ul>
            @forelse ($frutas as $fruta)
              <li><a href="{{ route('fruta', ['fruta' => $fruta->id]) }}">{{$fruta->nombre}} --- {{$fruta->temporada->temporada}}</a></li>
            @empty
              <li>No hay frutas en la BD</li>
            @endforelse
        </ul>
        <p><a href=" {{ route('inicio')}}">Inicio</a></p>
    </body>
</html>
