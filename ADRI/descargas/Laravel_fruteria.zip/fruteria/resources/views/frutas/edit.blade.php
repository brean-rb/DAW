<html>
    <head>
        <title>Modificar Fruta</title>
    </head>
    <body>
        <h3>Modificar Fruta</h3>
        @isset($error)
          {{ $error }}
        @endif

        @isset($fruta)
          {{$fruta->nombre}}    {{$fruta->precio_kg}}   {{$fruta->origen->origen}} {{$fruta->temporada->temporada}}
          <form action="{{ route('frutas.update', $fruta->id) }}" method="POST">
            @csrf
            @method('PUT');
            <div>
                <label for="precio_kg">Precio_Kg:</label>
                <input type="text" name="precio_kg" value="{{ $fruta->precio_kg }}">
            </div>
            <input type="submit" name="modificar" value="Modificar" />
          </form>
        @endisset
        <p><a href=" {{ route('inicio')}}">Inicio</a></p>
    </body>
</html>
