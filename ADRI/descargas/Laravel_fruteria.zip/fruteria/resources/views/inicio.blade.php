<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <title>Frutería</title>
    </head>
    <body>
        <p><a href=" {{ route('login')}}">Login</a></p>
        <p><a href="{{ route('listado') }}">Listado de frutas</a></p>
        @if(auth()->check())
          <p><a href=" {{ route('minimo')}}">Fruta más barata</a></p>
          <p><a href=" {{ route('maximo')}}">Fruta más cara</a></p>
          <p><a href=" {{ route('frutas.create')}}">Nueva fruta</a></p>
          <p><a href=" {{ route('logout')}}">Logout</a></p>
        @endif

    </body>
</html>
