<html>
    <head>
        <title>Nueva fruta</title>
    </head>
    <body>
        <h3>Nueva fruta</h3>
        <form name="nueva" action="<?php echo e(route('frutas.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div>
            <label for="nombre">Nombre:</label>
            <input type="text" name="nombre" value="<?php echo e(old('nombre')); ?>">
            </div>
            <div>
            <label for="precio_kg">Precio_Kg:</label>
            <input type="text" name="precio_kg" value="<?php echo e(old('precio_kg')); ?>">
            </div>
            <div>
            <label for="temporada_id">Temporada:</label>
            <select name="temporada_id">
               <?php $__currentLoopData = $temporadas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $temporada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <option value="<?php echo e($temporada->id); ?>">
                     <?php echo e($temporada->temporada); ?>

                   </option>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            </div>
            <div>
            <label for="origen_id">Origen:</label>
            <select name="origen_id">
               <?php $__currentLoopData = $origenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $origen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <option value="<?php echo e($origen->id); ?>">
                     <?php echo e($origen->origen); ?>

                   </option>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <p><label for="nuevo_origen">Nuevo origen:</label>
            <input type="text" name="nuevo_origen">
            </p>
            </div>

            <div>
            <input type="submit" name="crear" value="Crear">
            </div>
        </form>
    </body>
</html>

<?php /**PATH /opt/lampp/htdocs/fruteria/resources/views/frutas/create.blade.php ENDPATH**/ ?>