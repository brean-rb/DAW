<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <title>Frutería</title>
    </head>
    <body>
        <p><a href=" <?php echo e(route('login')); ?>">Login</a></p>
        <p><a href="<?php echo e(route('listado')); ?>">Listado de frutas</a></p>
        <?php if(auth()->check()): ?>
          <p><a href=" <?php echo e(route('minimo')); ?>">Fruta más barata</a></p>
          <p><a href=" <?php echo e(route('maximo')); ?>">Fruta más cara</a></p>
          <p><a href=" <?php echo e(route('frutas.create')); ?>">Nueva fruta</a></p>
          <p><a href=" <?php echo e(route('logout')); ?>">Logout</a></p>
        <?php endif; ?>

    </body>
</html>
<?php /**PATH /opt/lampp/htdocs/fruteria/resources/views/inicio.blade.php ENDPATH**/ ?>