<html>
    <head>
        <title>Fruta</title>
    </head>
    <body>
        <h3>Fruta</h3>
        <?php if(isset($error_eliminar)): ?>
          <?php echo e($error_eliminar); ?>

        <?php endif; ?>
        <?php if(isset($error)): ?>
          <?php echo e($error); ?>

        <?php endif; ?>

        <?php if(isset($fruta)): ?>
          <?php echo e($fruta->nombre); ?>    <?php echo e($fruta->precio_kg); ?>   <?php echo e($fruta->origen->origen); ?> <?php echo e($fruta->temporada->temporada); ?>

          <form action="<?php echo e(route('frutas.edit', $fruta->id)); ?>" method="GET">
            <?php echo csrf_field(); ?>
            <input type="submit" name="modificar" value="Modificar" />
          </form>
          <form action="<?php echo e(route('eliminar', $fruta->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field("DELETE"); ?>
            <input type="submit" name="eliminar" value="Eliminar" />
          </form>
        <?php endif; ?>
        <p><a href=" <?php echo e(route('inicio')); ?>">Inicio</a></p>

    </body>
</html>
<?php /**PATH /opt/lampp/htdocs/fruteria/resources/views/frutas/show.blade.php ENDPATH**/ ?>