<html>
    <head>
        <title>Listado de frutas</title>
    </head>
    <body>
        <h3>Listado de frutas</h3>
        <ul>
            <?php $__empty_1 = true; $__currentLoopData = $frutas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fruta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <li><a href="<?php echo e(route('fruta', ['fruta' => $fruta->id])); ?>"><?php echo e($fruta->nombre); ?> --- <?php echo e($fruta->temporada->temporada); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <li>No hay frutas en la BD</li>
            <?php endif; ?>
        </ul>
        <p><a href=" <?php echo e(route('inicio')); ?>">Inicio</a></p>
    </body>
</html>
<?php /**PATH /opt/lampp/htdocs/fruteria/resources/views/frutas/index.blade.php ENDPATH**/ ?>