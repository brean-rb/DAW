<html>
    <head>
        <title>Fruta precios max o min</title>
    </head>
    <body>
        <?php if(isset($frutaMin)): ?>
          <h3>Fruta con precio mínimo</h3>
          <?php echo e($frutaMin->nombre); ?>    <?php echo e($frutaMin->precio_kg); ?>   <?php echo e($frutaMin->origen->origen); ?> <?php echo e($frutaMin->temporada->temporada); ?>

        <?php endif; ?>
        <?php if(isset($frutaMax)): ?>
           <h3>Fruta con precio máximo</h3>
          <?php echo e($frutaMax->nombre); ?>    <?php echo e($frutaMax->precio_kg); ?>   <?php echo e($frutaMax->origen->origen); ?> <?php echo e($frutaMax->temporada->temporada); ?>

        <?php endif; ?>
        <p><a href=" <?php echo e(route('inicio')); ?>">Inicio</a></p>

    </body>
</html>
<?php /**PATH /opt/lampp/htdocs/fruteria/resources/views/frutas/maxmin.blade.php ENDPATH**/ ?>