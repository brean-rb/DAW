<html>
    <head>
        <title>Modificar Fruta</title>
    </head>
    <body>
        <h3>Modificar Fruta</h3>
        <?php if(isset($error)): ?>
          <?php echo e($error); ?>

        <?php endif; ?>

        <?php if(isset($fruta)): ?>
          <?php echo e($fruta->nombre); ?>    <?php echo e($fruta->precio_kg); ?>   <?php echo e($fruta->origen->origen); ?> <?php echo e($fruta->temporada->temporada); ?>

          <form action="<?php echo e(route('frutas.update', $fruta->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>;
            <div>
                <label for="precio_kg">Precio_Kg:</label>
                <input type="text" name="precio_kg" value="<?php echo e($fruta->precio_kg); ?>">
            </div>
            <input type="submit" name="modificar" value="Modificar" />
          </form>
        <?php endif; ?>
        <p><a href=" <?php echo e(route('inicio')); ?>">Inicio</a></p>
    </body>
</html>
<?php /**PATH /opt/lampp/htdocs/fruteria/resources/views/frutas/edit.blade.php ENDPATH**/ ?>