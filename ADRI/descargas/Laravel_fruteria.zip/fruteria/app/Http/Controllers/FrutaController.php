<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\ModelNotFoundException;

use App\Models\Fruta;
use App\Models\Temporada;
use App\Models\Origen;

class FrutaController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        // Lee todas la frutas y las pasa a la vista
        $frutas = Fruta::get();
        return view('frutas.index', compact('frutas'));

    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        // Busca las temporadas y orígenes
        $temporadas = Temporada::get();
        $origenes = Origen::get();

        return view('frutas.create', compact('temporadas', 'origenes'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // Crea la fruta del formulario y la guarda en la tabla
        $request->validate(
            [
                'nombre' => 'required',
                'precio_kg' => 'required|numeric|min:0'
            ]
        );
        $fruta = new Fruta();
        $fruta->nombre = strtoupper($request->get('nombre'));
        $fruta->precio_kg = $request->get('precio_kg');
        $fruta->temporada()->associate(Temporada::findOrFail($request->get('temporada_id')));
        if($request->has('nuevo_origen') && strlen($request->get('nuevo_origen')) > 1 ){
           // Comprueba que no existe este origen
           $existe_origen = Origen::where('origen', strtoupper($request->get('nuevo_origen')))->first();
           if(is_null($existe_origen)){
             $origen = new Origen();
             $origen->origen = strtoupper($request->get('nuevo_origen'));
             $origen->save();
             $fruta->origen()->associate($origen);
           }
           else{
            $fruta->origen()->associate($existe_origen);
           }
        }
        else{
           $fruta->origen()->associate(Origen::findOrFail($request->get('origen_id')));
        }
        $fruta->save();

        return redirect()->route('listado_frutas');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
        try {
            $fruta = Fruta::findOrFail($id);
            return view('frutas.show', compact('fruta'));
        }
        catch (ModelNotFoundException $e){
            $error = "Fruta no encontrada";
            return view('frutas.show', compact('error'));
        }
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
        try {
          $fruta = Fruta::findOrFail($id);
          return view('frutas.edit', compact('fruta'));
        }
        catch (ModelNotFoundException $e) {
          $error = "Fruta con ID: " . $id . " no encontrada.";
          return view('frutas.edit', compact('error'));
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
        if(isset($request['precio_kg'])){
          $request->validate(['precio_kg' => 'required|numeric']);
          $fruta = Fruta::findOrFail($id);
          if(!is_null($fruta)){
            $fruta->precio_kg = $request['precio_kg'];
            $fruta->save();
            return redirect()->route('listado_frutas');
          }
          else {
            $error = "Error modificar fruta con ID: " . $id;
            return view('frutas.edit', compact('error'));
          }
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
       try{
            $fruta = Fruta::findOrFail($id);
            $fruta->delete();
            return redirect()->route('listado_frutas');
        }
        catch (ModelNotFoundException $e) {
            $error_eliminar = "Error eliminar fruta con ID: " . $id;
            return view('frutas.show', compact('error_eliminar'));
        }
    }

    public function preciomax(){
        $frutaMax = Fruta::orderby('precio_kg', 'desc')->first();
        return view('frutas.maxmin', compact('frutaMax'));
    }
}
