<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Fruta extends Model
{
     // Relaciones con temporada y fruta
     public function temporada () {
        return $this->belongsTo(Temporada::class);
     }

     public function origen () {
         return $this->belongsTo(Origen::class);
      }
}
