/**
 * Represents a book.
 */
class Book {
  /**
   * Creates a book.
   * @param {string} title - The title of the book.
   * @param {string} author - The author of the book.
   */
  constructor(title, author) {
    this.title = title;
    this.author = author;
  }

  /**
   * Returns a description of the book.
   * @returns {string} A formatted description of the book.
   */
  getDescription() {
    return `${this.title} by ${this.author}`;
  }
}
