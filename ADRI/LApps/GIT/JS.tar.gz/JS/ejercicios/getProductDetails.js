/**
 * Retrieves details of a product.
 * @param {Object} product - The product object.
 * @param {string} product.name - The name of the product.
 * @param {number} product.price - The price of the product.
 * @param {string[]} product.tags - An array of product tags.
 * @returns {string} Product details in a formatted string.
 */
function getProductDetails(product) {
  return `${product.name} costs $${product.price} and has tags: ${product.tags.join(", ")}.`;
}
