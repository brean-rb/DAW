/**
 * Subtracts one number from another.
 * @param {number} a - The number to subtract from.
 * @param {number} b - The number to subtract.
 * @returns {number} The result of the subtraction.
 */
function subtract(a, b) {
  return a - b;
}
